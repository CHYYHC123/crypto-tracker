const A=["ZS","CRCL","AAPL","NVDA","TSLA","GOOGL","SPCX"],S=["NVDA","AAPL","GOOGL","MSFT","AMZN","AVGO"];new Set(A);export{A as D,S as P};
