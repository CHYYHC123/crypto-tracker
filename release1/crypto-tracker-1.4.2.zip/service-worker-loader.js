import './assets/index.js-ql8NVVZP.js';
