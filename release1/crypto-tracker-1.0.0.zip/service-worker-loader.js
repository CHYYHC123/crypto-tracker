import './assets/index.js-cgMxwdBk.js';
