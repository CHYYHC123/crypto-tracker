import './assets/index.js-qX5kKTYC.js';
