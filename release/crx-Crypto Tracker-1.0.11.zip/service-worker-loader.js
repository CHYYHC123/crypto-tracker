import './assets/index.js-B4js52Iv.js';
