import './assets/index.js-CZXbOJWM.js';
