import './assets/index.js-okGBif2j.js';
